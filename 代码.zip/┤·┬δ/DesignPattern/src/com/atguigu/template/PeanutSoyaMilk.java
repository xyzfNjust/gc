package com.atguigu.template;

public class PeanutSoyaMilk extends SoyaMilk {

	@Override
	void addCondiments() {
		// TODO Auto-generated method stub
		System.out.println(" �����ϺõĻ��� ");
	}

}
