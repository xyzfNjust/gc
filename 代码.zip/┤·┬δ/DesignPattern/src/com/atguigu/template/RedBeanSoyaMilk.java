package com.atguigu.template;

public class RedBeanSoyaMilk extends SoyaMilk {

	@Override
	void addCondiments() {
		// TODO Auto-generated method stub
		System.out.println(" �����Ϻõĺ춹 ");
	}

}
