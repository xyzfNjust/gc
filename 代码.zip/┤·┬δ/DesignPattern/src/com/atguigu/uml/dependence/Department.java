package com.atguigu.uml.dependence;

public class Department {

}
