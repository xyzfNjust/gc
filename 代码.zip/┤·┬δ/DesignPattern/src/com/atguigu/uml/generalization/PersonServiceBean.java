package com.atguigu.uml.generalization;

public class PersonServiceBean extends DaoSupport {

}
