package com.atguigu.jdk;

public class Observer {
	public static void main(String[] args) {
		
		// Observable
	}
}
