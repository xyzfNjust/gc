package com.atguigu.spring.test;

public class Adapter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//DispatcherServlet 
	}

}
