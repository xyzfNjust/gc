package com.atguigu.spring.test;

public class Template {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// 1. ConfigurableApplicationContext 
		
		// JdbcTemplate 
		
		
	}

}
